# Ask the user for a number
num = int(input("Enter a number: "))

# Check if the number is even or odd
if num % 2 == 0:
    print(f"The number {num} is even.")
else:
    print(f"The number {num} is odd.")
import pytest

@pytest.fixture
def number_list():
    return list(range(11))
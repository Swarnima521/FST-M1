def my_sum(numbers):
    total = 0
    for num in numbers:
        total += num
    print("The sum of the elements is:", total)


my_list = [10, 20, 30, 5]
my_sum(my_list)
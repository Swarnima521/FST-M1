CREATE TABLE salesman (
    salesman_id    INT,
    salesman_name  VARCHAR2(20),
    salesman_city  VARCHAR2(20),
    commission     INT
);
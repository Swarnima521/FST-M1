package activities;

public abstract class Book {
	String title;
	abstract void setTitle(String t);
	
	String getTitle() {
		return title;
	}
}
package activities;

public interface BicycleParts {
	public int tyres = 4;
	public int maxSpeed = 20;
}
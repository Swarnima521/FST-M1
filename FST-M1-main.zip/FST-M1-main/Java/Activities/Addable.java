package activities;

@FunctionalInterface
public interface Addable {
	int add(int num1, int num2);
}